package 行列簡約化;

public class X {

}
